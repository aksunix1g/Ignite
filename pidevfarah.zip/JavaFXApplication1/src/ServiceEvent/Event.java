/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ServiceEvent;

import Service.IServiceEvent;
import entities.Evenement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.Connexion;

/**
 *
 * @author 2018
 */
public class Event implements IServiceEvent{

    
    private Connection con;
    private Statement ste;

    public Event() {
        con = Connexion.getinstance().getCnx();
    }
    
    @Override
    public void AddEvent(Evenement e) {
        
        try {
            PreparedStatement pre=con.prepareStatement("INSERT INTO evenement (event_name,event_date,event_type,event_description,event_img) VALUES (?,?,?,?,?);");
            pre.setString(1,e.getEvent_name());
            pre.setDate(2,(Date)e.getEvent_date());
            pre.setString(3,e.getEvent_type());
            pre.setString(4,e.getEvent_desc());
            pre.setString(5,e.getEvent_img());
            pre.executeUpdate();
//To change body of generated methods, choose Tools | Templates.
        } catch (SQLException ex) {
            Logger.getLogger(Event.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public List<Evenement> AfficherEvent() throws SQLException{
        
            Statement stm = con.createStatement();
            String query = "select * from evenement";
            ResultSet rst = stm.executeQuery(query);
            List<Evenement> evt = new ArrayList<>();
            while (rst.next()) {

            Evenement event = new Evenement();
            event.setEvent_id(rst.getInt("event_id"));
            event.setEvent_name(rst.getString("event_name"));
            event.setEvent_type(rst.getString("event_type"));
            event.setEvent_date(rst.getDate("event_date"));
            event.setEvent_desc(rst.getString("event_description"));
           event.setEvent_img(rst.getString("event_img"));
            
            evt.add(event);
            }  
            
        
        
        return evt;
    }
    
    
}
