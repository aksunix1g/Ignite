/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxapplication1;

import Service.IServiceEvent;
import ServiceEvent.Event;
import entities.Evenement;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javax.imageio.ImageIO;

/**
 * FXML Controller class
 *
 * @author 2018
 */
public class FXMLDocumentController implements Initializable {
    File fl;
    Image imgdef;
    Event ev=new Event();
    @FXML
    private TextField tf_name;
    @FXML
    private DatePicker tf_date;
    @FXML
    private TextArea ta_desc;
    @FXML
    private TextField tf_type;
    @FXML
    private Button upload;
    @FXML
    private ImageView testimg;
    @FXML
    private Button ajoute;

    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void ajouterEvent(ActionEvent event) {
        Evenement e=new Evenement();
        e.setEvent_desc(ta_desc.getText());
        e.setEvent_name(tf_name.getText());
        e.setEvent_type(tf_type.getText());
       e.setEvent_date(Date.valueOf(tf_date.getValue()));
       e.setEvent_img(fl.getAbsolutePath());
        ev.AddEvent(e);
    }

    @FXML
    private void upload_img(ActionEvent event) {
        imgdef=testimg.getImage();
        FileChooser fc=new FileChooser();
        fc.setInitialDirectory(new File("C:\\Users\\2018\\Desktop"));
        fl=fc.showOpenDialog(null);
        try {
            BufferedImage bi=ImageIO.read(fl);
            Image imgg=SwingFXUtils.toFXImage(bi, null);
            testimg.setImage(imgg);
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
