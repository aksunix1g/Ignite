/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxapplication1;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;

/**
 * FXML Controller class
 *
 * @author 2018
 */
public class DetailController implements Initializable {

    @FXML
    private Label lb_name;
    @FXML
    private Label lb_type;
    @FXML
    private Label lb_type1;
    @FXML
    private TextArea lb_desc;

    AfficherController ac=new AfficherController();
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
        
    }    
    
}
