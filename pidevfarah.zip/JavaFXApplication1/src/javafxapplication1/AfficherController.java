/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxapplication1;

import ServiceEvent.Event;
import entities.Evenement;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Paint;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javax.imageio.ImageIO;

/**
 * FXML Controller class
 *
 * @author 2018
 */
public class AfficherController implements Initializable {

    @FXML
    private VBox vlist;
    Event ev=new Event();
    List evt=new ArrayList();
    @FXML
    private Button add;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       vlist.setSpacing(10);
        try {
             
            List evt=ev.AfficherEvent();
            ObservableList obs=FXCollections.observableArrayList(evt);
        for(int i=0;i<obs.size();i++){
            HBox hb=new HBox();
            Evenement e=new Evenement();
            e=(Evenement)obs.get(i);
           
                    BufferedImage bi=ImageIO.read(new File(e.getEvent_img()));
                    Image imgg=SwingFXUtils.toFXImage(bi, null);
                    ImageView iv=new ImageView(imgg);
                    iv.setFitWidth(150);
                    iv.setFitHeight(100);
                    hb.getChildren().add(iv);
                    Label lb=new Label(e.getEvent_name());
                    
                    lb.setTextFill(Paint.valueOf("#000000"));
                    lb.setFont(new Font("Arial", 24));
                    lb.setPadding(new Insets(30,0,0,0));
                    hb.getChildren().add(lb);
                   
                    hb.setSpacing(20);
                    
                    vlist.getChildren().add(hb);
                    
                    hb.setOnMouseClicked(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent event) {
                        try {
                            Stage stage=new Stage();
                            Parent root = FXMLLoader.load(getClass().getResource("Detail.fxml"));
                            
                            Scene scene = new Scene(root);
                            stage.setScene(scene);
                            stage.show();   } catch (IOException ex) {
                            Logger.getLogger(AfficherController.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                    });
        }
     } catch (SQLException ex) {
            Logger.getLogger(AfficherController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(AfficherController.class.getName()).log(Level.SEVERE, null, ex);
        }
        }    

    @FXML
    private void ajouter_evt(ActionEvent event) throws IOException {
        Stage stage=new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    

   
    
}
