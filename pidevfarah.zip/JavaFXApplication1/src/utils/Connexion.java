/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author 2018
 */
public class Connexion {
    final static String url="jdbc:mysql://127.0.0.1:3306/ignite";
    final static String Login="root";
    final static String PWD="";
    static Connexion instance=null;
    private Connection cnx;
     
    private Connexion (){
        try{
            cnx=DriverManager.getConnection(url, Login, PWD);
            System.out.println("connexion etablie");
    }
        catch(SQLException s){
        System.out.println("pas de connexion");
        }
    
    
}
    public static Connexion getinstance(){
        if (instance == null) {
            instance = new Connexion();
            
        }
    return instance;
    }

    public Connection getCnx() {
        return cnx;
    }
    
}